#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import copy
import datetime as _dt
import os
import re
import sys
import zipfile
from pathlib import Path

from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt
from docx.text.run import Run


# ----------------------------
# CONFIG
# ----------------------------

COLOR_PAGE_BG = "1E1E1E"

COLOR_TEXT = "DDDDDD"
COLOR_BOLD = "DC3C28"
COLOR_HEADING = "05AAC7"   # final heading color

COLOR_TABLE_BORDER = "AFA082"
COLOR_TABLE_CELL = "006478"
COLOR_TABLE_HEADER = "802000"

COLOR_TABLE_REPLACE_RED = "B4A087"  # in-table: DC3C28 -> B4A087
COLOR_BLACK_TO = "B4A087"

COLOR_TIME_TEXT = "EC6641"          # RGB(236,102,65)
COLOR_TIME_BG = "D7C3A5"            # replaces RGB(204,255,255)

FONT_MAIN = "Ekin Pro Text"
FONT_PAGE_NUM = "Ekin Pro Joker"

PT_MAIN = 13
PT_HEADING = 11
PT_TABLE = 11
PT_PAGE_NUM = 13

LINE_SPACING = 1.05

CHAR_SPACING_PT = 0.35  # "0,35 nk"
CHAR_SPACING_W_VAL = str(int(round(CHAR_SPACING_PT * 20)))  # 1/20 pt

FONT_SCALE = "100"  # 100%

EMOJI_FONT = "Apple Color Emoji"
EMOJI_PT = 8.5

REPLACE_ARROW = "💎"
REPLACE_BULLET = "🔮"
REPLACE_DASH = "🇹🇷"
REPLACE_STAR = "⭐️"

# Special tokens (as provided)
SPECIAL_TOKENS = [
    "Kural=",
    "İstisna=",
    "NOT 5=",
    "NOT 4=",
    "NOT 3 =",
    "NOT 2 =",
    "NOT 1=",
    "NOT=",
]

# Time expressions
RE_TIME_NUM_UNIT = re.compile(
    r"\b(\d{1,4})(\s+)(yıl|yıllık|ay|aylık|hafta|haftalık|gün|günlük)\b",
    re.IGNORECASE,
)

RE_TIME_NUM_DAN = re.compile(
    r"\b(\d{1,4})(\s+)(yıl|ay|hafta|gün)(dan|den|tan|ten)\s+(fazla|çok|az)\b",
    re.IGNORECASE,
)

RE_TIME_DAN_NO_NUM = re.compile(
    r"\b(yıl|ay|hafta|gün)(dan|den|tan|ten)\s+(fazla|çok|az)\b",
    re.IGNORECASE,
)


# ----------------------------
# XML helpers
# ----------------------------

def _get_or_add_rpr(run):
    r = run._r
    rPr = r.rPr
    if rPr is None:
        rPr = OxmlElement("w:rPr")
        r.insert(0, rPr)
    return rPr


def set_run_scale_100(run):
    rPr = _get_or_add_rpr(run)
    w = rPr.find(qn("w:w"))
    if w is None:
        w = OxmlElement("w:w")
        rPr.append(w)
    w.set(qn("w:val"), FONT_SCALE)


def set_run_char_spacing(run):
    rPr = _get_or_add_rpr(run)
    sp = rPr.find(qn("w:spacing"))
    if sp is None:
        sp = OxmlElement("w:spacing")
        rPr.append(sp)
    sp.set(qn("w:val"), CHAR_SPACING_W_VAL)


def set_run_shading(run, fill_hex):
    rPr = _get_or_add_rpr(run)
    shd = rPr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        rPr.append(shd)
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), fill_hex.upper())


def clear_run_shading(run):
    rPr = _get_or_add_rpr(run)
    shd = rPr.find(qn("w:shd"))
    if shd is not None:
        rPr.remove(shd)


def get_run_color_hex(run):
    c = run.font.color.rgb
    if c is None:
        return None
    return str(c).upper()


def set_run_color_hex(run, hex6):
    if hex6 is None:
        run.font.color.rgb = None
        return
    from docx.shared import RGBColor
    run.font.color.rgb = RGBColor.from_string(hex6.upper())


def set_run_font(run, name, size_pt):
    run.font.name = name
    # Also set for East Asian fonts to avoid fallback
    rPr = _get_or_add_rpr(run)
    rFonts = rPr.find(qn("w:rFonts"))
    if rFonts is None:
        rFonts = OxmlElement("w:rFonts")
        rPr.append(rFonts)
    rFonts.set(qn("w:ascii"), name)
    rFonts.set(qn("w:hAnsi"), name)
    rFonts.set(qn("w:cs"), name)
    rFonts.set(qn("w:eastAsia"), name)

    if size_pt is not None:
        run.font.size = Pt(size_pt)


def set_cell_shading(cell, fill_hex):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = tcPr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tcPr.append(shd)
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), fill_hex.upper())


def set_table_borders(table, color_hex, sz="8"):
    tbl = table._tbl
    tblPr = tbl.tblPr
    if tblPr is None:
        tblPr = OxmlElement("w:tblPr")
        tbl.insert(0, tblPr)

    borders = tblPr.find(qn("w:tblBorders"))
    if borders is None:
        borders = OxmlElement("w:tblBorders")
        tblPr.append(borders)

    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        el = borders.find(qn(f"w:{edge}"))
        if el is None:
            el = OxmlElement(f"w:{edge}")
            borders.append(el)
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), str(sz))
        el.set(qn("w:space"), "0")
        el.set(qn("w:color"), color_hex.upper())


def set_document_background(doc, color_hex):
    document_elm = doc._part._element  # w:document
    bg = document_elm.find(qn("w:background"))
    if bg is None:
        bg = OxmlElement("w:background")
        # Insert as first child
        document_elm.insert(0, bg)
    bg.set(qn("w:color"), color_hex.upper())


def iter_tables(table):
    yield table
    for row in table.rows:
        for cell in row.cells:
            for t in cell.tables:
                yield from iter_tables(t)


def paragraph_in_table(paragraph):
    # Detect by walking up XML parents
    p = paragraph._p
    parent = p.getparent()
    while parent is not None:
        if parent.tag == qn("w:tc"):
            return True
        parent = parent.getparent()
    return False


def has_numbering(paragraph):
    pPr = paragraph._p.pPr
    if pPr is None:
        return False
    return pPr.numPr is not None


def is_heading_like(paragraph):
    txt = (paragraph.text or "").strip()
    if not txt:
        return False

    style_name = ""
    try:
        style_name = paragraph.style.name or ""
    except Exception:
        style_name = ""

    if style_name.lower().startswith("heading"):
        return True

    # Outline level
    pPr = paragraph._p.pPr
    if pPr is not None:
        ol = pPr.outlineLvl
        if ol is not None:
            return True

    # Short, bold-ish, not too long
    if len(txt) <= 80:
        if any((r.bold for r in paragraph.runs if r.text.strip())):
            # Avoid treating list items as headings unless they look like title
            if not has_numbering(paragraph) and not re.match(r"^\s*\d+[\)\.\-]", txt):
                return True

    # ALL CAPS titles
    if len(txt) <= 60 and txt == txt.upper() and any(ch.isalpha() for ch in txt):
        return True

    return False


def is_numbered_heading(paragraph):
    txt = (paragraph.text or "").strip()
    if not txt:
        return False
    if has_numbering(paragraph):
        # If it's a numbered list and looks like a title-ish line
        if len(txt) <= 120 and any((r.bold for r in paragraph.runs if r.text.strip())):
            return True
        # Also detect common numbering patterns
        if re.match(r"^\s*\d{1,3}[\)\.\-]\s*\S+", txt):
            return True
        return False

    # Manual numbering patterns without Word numbering
    if re.match(r"^\s*\d{1,3}[\)\.\-]\s*\S+", txt):
        return True

    return False


# ----------------------------
# Run insertion/splitting
# ----------------------------

def insert_run_after(paragraph, after_run, text, copy_format_from=None, font_name=None, size_pt=None, color_hex=None, bold=None):
    new_r = OxmlElement("w:r")
    after_run._r.addnext(new_r)
    new_run = Run(new_r, paragraph)

    if copy_format_from is not None:
        src_rPr = copy.deepcopy(_get_or_add_rpr(copy_format_from))
        # Replace any existing rPr
        if new_run._r.rPr is not None:
            new_run._r.remove(new_run._r.rPr)
        new_run._r.insert(0, src_rPr)

    # Set text
    t = OxmlElement("w:t")
    # Preserve leading/trailing spaces
    if text.startswith(" ") or text.endswith(" "):
        t.set(qn("xml:space"), "preserve")
    t.text = text
    new_run._r.append(t)

    # Apply explicit overrides
    if font_name is not None or size_pt is not None:
        set_run_font(new_run, font_name or (copy_format_from.font.name if copy_format_from else FONT_MAIN), size_pt)
    if color_hex is not None:
        set_run_color_hex(new_run, color_hex)
    if bold is not None:
        new_run.bold = bool(bold)

    return new_run


def replace_in_run_with_emoji(paragraph, run, needle, emoji_char):
    if needle not in run.text:
        return

    original_text = run.text
    idx = original_text.find(needle)
    # Only replace first occurrence per call; we'll loop
    before = original_text[:idx]
    after = original_text[idx + len(needle):]

    # Keep original formatting for before/after
    run.text = before

    # Insert emoji run
    emoji_run = insert_run_after(
        paragraph,
        run,
        emoji_char,
        copy_format_from=None,
        font_name=EMOJI_FONT,
        size_pt=EMOJI_PT,
        color_hex=None,
        bold=None,
    )
    set_run_scale_100(emoji_run)
    set_run_char_spacing(emoji_run)

    # Insert tail run with original formatting (copy)
    tail_run = insert_run_after(
        paragraph,
        emoji_run,
        after,
        copy_format_from=run,
        font_name=None,
        size_pt=None,
        color_hex=None,
        bold=None,
    )
    # Make sure tail run uses main font (not emoji)
    set_run_font(tail_run, run.font.name or FONT_MAIN, run.font.size.pt if run.font.size else PT_MAIN)
    set_run_scale_100(tail_run)
    set_run_char_spacing(tail_run)


def replace_all_needle_with_emoji(paragraph, needle, emoji_char):
    # Iterate over a snapshot because we mutate runs
    runs = list(paragraph.runs)
    for r in runs:
        while needle in r.text:
            replace_in_run_with_emoji(paragraph, r, needle, emoji_char)
            # After splitting, continue on the tail run if needed
            # The outer pass + a second pass catches remaining occurrences.
            break
    # Second pass to catch remaining occurrences
    for r in list(paragraph.runs):
        while needle in r.text:
            replace_in_run_with_emoji(paragraph, r, needle, emoji_char)


def replace_line_start_symbol(paragraph, in_table):
    if in_table:
        return
    full = paragraph.text
    if not full:
        return

    # Determine first non-whitespace character position
    m = re.search(r"\S", full)
    if not m:
        return
    pos = m.start()
    ch = full[pos]
    if ch not in ("-", "*"):
        return

    emoji = REPLACE_DASH if ch == "-" else REPLACE_STAR

    # Walk runs to find the run containing this position
    cur = 0
    for r in paragraph.runs:
        t = r.text or ""
        nxt = cur + len(t)
        if cur <= pos < nxt:
            local = pos - cur
            before = t[:local]
            after = t[local + 1:]

            r.text = before
            emoji_run = insert_run_after(
                paragraph,
                r,
                emoji,
                copy_format_from=None,
                font_name=EMOJI_FONT,
                size_pt=EMOJI_PT,
                color_hex=None,
                bold=None,
            )
            set_run_scale_100(emoji_run)
            set_run_char_spacing(emoji_run)

            tail = insert_run_after(
                paragraph,
                emoji_run,
                after,
                copy_format_from=r,
                font_name=None,
                size_pt=None,
                color_hex=None,
                bold=None,
            )
            set_run_font(tail, r.font.name or FONT_MAIN, r.font.size.pt if r.font.size else PT_MAIN)
            set_run_scale_100(tail)
            set_run_char_spacing(tail)
            break
        cur = nxt


# ----------------------------
# Time highlighting across runs
# ----------------------------

def _run_spans(paragraph):
    spans = []
    cur = 0
    for r in paragraph.runs:
        t = r.text or ""
        if not t:
            continue
        start = cur
        end = cur + len(t)
        spans.append((r, start, end))
        cur = end
    return spans, cur


def apply_time_highlights(paragraph):
    text = paragraph.text or ""
    if not text:
        return

    spans, _ = _run_spans(paragraph)
    if not spans:
        return

    matches = []
    for rx in (RE_TIME_NUM_DAN, RE_TIME_NUM_UNIT, RE_TIME_DAN_NO_NUM):
        for m in rx.finditer(text):
            matches.append((m.start(), m.end()))

    if not matches:
        return

    # Merge overlaps
    matches.sort()
    merged = []
    for s, e in matches:
        if not merged or s > merged[-1][1]:
            merged.append([s, e])
        else:
            merged[-1][1] = max(merged[-1][1], e)

    for s, e in merged:
        for r, rs, re_ in spans:
            if re_ <= s or rs >= e:
                continue
            # Apply time formatting to runs intersecting the match (includes numbers even if split across runs)
            set_run_color_hex(r, COLOR_TIME_TEXT)
            set_run_shading(r, COLOR_TIME_BG)


def enforce_two_spaces_in_time_units(paragraph):
    # Update text in-place run by run (keeps formatting)
    for r in paragraph.runs:
        t = r.text or ""
        if not t:
            continue

        # 5 yıl -> 5␠␠yıl
        def _sub_unit(m):
            return f"{m.group(1)}  {m.group(3)}"

        t2 = RE_TIME_NUM_UNIT.sub(_sub_unit, t)

        # 5 yıldan az -> 5␠␠yıldan az (only when the suffix pattern is inside same run)
        def _sub_dan(m):
            return f"{m.group(1)}  {m.group(3)}{m.group(4)} {m.group(5)}"

        t3 = RE_TIME_NUM_DAN.sub(_sub_dan, t2)
        r.text = t3


# ----------------------------
# Main formatting logic
# ----------------------------

def apply_run_base_format(run, in_table, is_heading, is_num_heading):
    orig = get_run_color_hex(run)

    # Base font sizing by context
    size_pt = PT_MAIN
    if is_heading or is_num_heading:
        size_pt = PT_HEADING
    if in_table:
        size_pt = PT_TABLE

    # Force core font and spacing/scale
    set_run_font(run, FONT_MAIN, size_pt)
    set_run_scale_100(run)
    set_run_char_spacing(run)

    # Determine color
    # 1) If heading-like: fixed heading color
    if is_heading or is_num_heading:
        run.bold = True
        set_run_color_hex(run, COLOR_HEADING)
        return

    # 2) Preserve boldness and recolor bold text
    if run.bold:
        set_run_color_hex(run, COLOR_BOLD)
    else:
        # If originally colored as 64E1FA or 55A8E7, convert accordingly
        if orig in ("64E1FA", "55A8E7"):
            if in_table:
                set_run_color_hex(run, COLOR_TABLE_HEADER)
            else:
                set_run_color_hex(run, COLOR_HEADING)
        elif orig == "000000":
            set_run_color_hex(run, COLOR_BLACK_TO)
        else:
            set_run_color_hex(run, COLOR_TEXT)

    # Table-specific replacements based on ORIGINAL colors
    if in_table:
        if orig == "DC3C28":
            set_run_color_hex(run, COLOR_TABLE_REPLACE_RED)
        elif orig == "AFA082":
            set_run_color_hex(run, COLOR_TEXT)
        elif orig == "55A8E7" or orig == "64E1FA":
            set_run_color_hex(run, COLOR_TABLE_HEADER)


def apply_special_token_rule(paragraph):
    # If token text is present and the run is B4A087 -> make it DC3C28
    for r in paragraph.runs:
        t = r.text or ""
        if not t:
            continue
        if any(tok in t for tok in SPECIAL_TOKENS):
            c = get_run_color_hex(r)
            if c == "B4A087":
                set_run_color_hex(r, COLOR_BOLD)


def process_paragraph(paragraph, in_table):
    # Paragraph line spacing
    try:
        paragraph.paragraph_format.line_spacing = LINE_SPACING
    except Exception:
        pass

    is_heading = (not in_table) and is_heading_like(paragraph)
    is_num_heading = (not in_table) and is_numbered_heading(paragraph)

    # First pass: base run formatting + color mapping
    for r in paragraph.runs:
        apply_run_base_format(r, in_table=in_table, is_heading=is_heading, is_num_heading=is_num_heading)

    # Apply special token color change
    apply_special_token_rule(paragraph)

    # Enforce time spacing in text
    enforce_two_spaces_in_time_units(paragraph)

    # Highlight time expressions across runs (includes numbers if split across runs)
    apply_time_highlights(paragraph)

    # Emoji replacements
    replace_all_needle_with_emoji(paragraph, "=>", REPLACE_ARROW)
    replace_all_needle_with_emoji(paragraph, "•", REPLACE_BULLET)

    # Line-start replacements (skip tables)
    replace_line_start_symbol(paragraph, in_table=in_table)


def process_table(table):
    # Borders
    set_table_borders(table, COLOR_TABLE_BORDER, sz="8")

    # Cell shading and text
    for r_idx, row in enumerate(table.rows):
        for cell in row.cells:
            fill = COLOR_TABLE_HEADER if r_idx == 0 else COLOR_TABLE_CELL
            set_cell_shading(cell, fill)

            for p in cell.paragraphs:
                process_paragraph(p, in_table=True)


def process_docx(in_path: Path, out_path: Path):
    doc = Document(str(in_path))

    # Page background
    set_document_background(doc, COLOR_PAGE_BG)

    # Body paragraphs (outside tables)
    for p in doc.paragraphs:
        process_paragraph(p, in_table=False)

    # Tables (including nested)
    for t in list(doc.tables):
        for tt in iter_tables(t):
            process_table(tt)

    # Footer page numbers: set all footer runs to Ekin Pro Joker 13pt #7E7E7E
    for section in doc.sections:
        footer = section.footer
        for p in footer.paragraphs:
            for r in p.runs:
                set_run_font(r, FONT_PAGE_NUM, PT_PAGE_NUM)
                set_run_scale_100(r)
                set_run_char_spacing(r)
                set_run_color_hex(r, "7E7E7E")

    doc.save(str(out_path))

    # After save: XML-level replacements for shapes/characters colored black -> B4A087, and shading CCFFFF -> D7C3A5
    patch_docx_zip(out_path)


def patch_docx_zip(docx_path: Path):
    tmp_path = docx_path.with_suffix(".tmp.docx")
    if tmp_path.exists():
        tmp_path.unlink()

    with zipfile.ZipFile(docx_path, "r") as zin, zipfile.ZipFile(tmp_path, "w", compression=zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename.endswith(".xml"):
                try:
                    txt = data.decode("utf-8")
                except Exception:
                    zout.writestr(item, data)
                    continue

                # Text/shape color black -> B4A087
                txt = re.sub(r'(w:color[^>]*w:val=")000000(")', r"\1" + COLOR_BLACK_TO + r"\2", txt, flags=re.IGNORECASE)
                txt = re.sub(r'(a:srgbClr[^>]*val=")000000(")', r"\1" + COLOR_BLACK_TO + r"\2", txt, flags=re.IGNORECASE)
                txt = re.sub(r'(w:shd[^>]*w:fill=")000000(")', r"\1" + COLOR_BLACK_TO + r"\2", txt, flags=re.IGNORECASE)

                # Any CCFFFF shading/fills -> D7C3A5
                txt = re.sub(r'(w:shd[^>]*w:fill=")CCFFFF(")', r"\1" + COLOR_TIME_BG + r"\2", txt, flags=re.IGNORECASE)
                txt = re.sub(r'(a:srgbClr[^>]*val=")CCFFFF(")', r"\1" + COLOR_TIME_BG + r"\2", txt, flags=re.IGNORECASE)

                data = txt.encode("utf-8")

            zout.writestr(item, data)

    # Replace original
    os.replace(tmp_path, docx_path)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in_dir", required=True, help="Input folder containing .docx files")
    ap.add_argument("--out_dir", required=False, default="", help="Output folder (default: <in_dir>/OLACAK_OUT)")
    args = ap.parse_args()

    in_dir = Path(os.path.expanduser(args.in_dir)).resolve()
    if not in_dir.exists() or not in_dir.is_dir():
        print(f"IN_DIR bulunamadı: {in_dir}", file=sys.stderr)
        sys.exit(2)

    out_dir = Path(os.path.expanduser(args.out_dir)).resolve() if args.out_dir else (in_dir / "OLACAK_OUT")
    out_dir.mkdir(parents=True, exist_ok=True)

    ts = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    files = sorted([p for p in in_dir.iterdir() if p.is_file() and p.suffix.lower() == ".docx" and not p.name.startswith("~$")])

    if not files:
        print("Klasörde .docx bulunamadı.", file=sys.stderr)
        sys.exit(1)

    ok = 0
    for f in files:
        out_name = f"{f.stem}_OLACAK_{ts}.docx"
        out_path = out_dir / out_name
        try:
            process_docx(f, out_path)
            ok += 1
            print(f"OK: {out_path.name}")
        except Exception as e:
            print(f"FAIL: {f.name} -> {e}", file=sys.stderr)

    # Final message
    msg = "OLACAK OLACAK"
    print(msg)

    # Optional macOS pop-up (non-fatal)
    try:
        if sys.platform == "darwin":
            import subprocess
            subprocess.run(
                ["osascript", "-e", f'display dialog "{msg}" with title "{msg}" buttons {{"OK"}} default button 1'],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        else:
            # Headless-safe fallback (no blocking GUI)
            pass
    except Exception:
        pass

    if ok == 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
